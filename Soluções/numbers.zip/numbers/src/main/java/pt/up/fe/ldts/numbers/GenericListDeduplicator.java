package pt.up.fe.ldts.numbers;

import java.util.List;

public interface GenericListDeduplicator {
    public List<Integer> deduplicate(List<Integer> list);
}
