package pt.up.fe.ldts.numbers;

public interface GenericListFilter {
    public boolean accept(Integer number);
}
