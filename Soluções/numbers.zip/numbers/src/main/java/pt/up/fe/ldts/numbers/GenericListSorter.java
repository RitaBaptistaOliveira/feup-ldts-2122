package pt.up.fe.ldts.numbers;

import java.util.List;

public interface GenericListSorter {
    public List<Integer> sort(List<Integer> list);
}
